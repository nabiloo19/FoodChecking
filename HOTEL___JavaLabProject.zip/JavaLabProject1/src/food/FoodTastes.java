package food;

public class FoodTastes {

	public int OptimumSaltGram = 20, OptimumFatGram = 40; // Optimum values

	public int getOptimumSaltGram() { // returning optimum SALT
		return OptimumSaltGram;
	}

	public int getOptimumFatGram() { // returning optimum FAT
		return OptimumFatGram;
	}

	public void setCustomTaste(int salt, int fat) { // setting custom values to overwrite the Optimum values

		this.OptimumSaltGram = salt;
		this.OptimumFatGram = fat;

	}

	public void setDefaultTaste() { // re-setting values to their optimum values
		this.OptimumSaltGram = 20;
		this.OptimumFatGram = 40;

	}

	public boolean isSalty(int salt) { // checking saltty

		if (salt > OptimumSaltGram) {

			return true;

		}

		else {

			return false;
		}

	}

	public boolean isFatty(int fat) { // checking fatty

		if (fat > OptimumFatGram) {

			return true;

		}

		else {

			return false;
		}
	}

	public boolean isHealthy(int salt, int fat) { // UNUSED FUNCTION

		if (isSalty(salt) && isFatty(fat)) {

			return false;
		}

		else {

			return true;

		}

	}

}
