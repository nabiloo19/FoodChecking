package food;

public class Food extends FoodTastes { // inherting the FoodTastes Class

	public static int foodCount; // static variable of counting food
	
	public String ChefName, foodName; // String variables
	public int fat, salt; // Integers variables

	public Food() { // constructor, intilizing values to 0 and null

		foodCount = 0;
		foodName = null;
		salt = 0;
		fat = 0;
		ChefName = null;
	}

	public void cook(String foodName, int salt, int fat, String ChefName) { // cooking method

		this.foodCount++;
		this.foodName = foodName;
		this.salt = salt;
		this.fat = fat;
		this.ChefName = ChefName;

	}

	public String getFoodName() { // returning Food Name

		return foodName;

	}

	public String getChefName() { // returning Chef Name

		return ChefName;

	}

	public int getSalt() { // returning SALT

		return salt;
	}

	public int getFat() { // returning FAT
		return fat;
	}

	}
