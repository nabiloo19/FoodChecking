/*
 * JAVA LAB PROJECT
 * 
 * DONE BY: #SERAJ -> #YEDENKECAHAW -> #NABIL -> #Yonatan
 * 
 * LAST UPDATE:JUNE 7, at 10:38PM
 * 
 */

package hotel;

import food.Food; // only one import process, since we used inheritance concept
import java.util.*; // of Scanner
import java.time.*; // of Time

public class Hotel {

	static int hour, minute, second;

	public static void main(String[] args) { // Main Function

		int sa = 0, fa = 0, iterate = 0, check = 0, menu = 0, fCount = 0; // Integer variables intilization
		String Cname = null, Fname = null, tableNo = null; // String variables intilization

		Scanner sc;
		sc = new Scanner(System.in); // Input Object

		ArrayList<Food> a = new ArrayList<Food>();// for chef only
		ArrayList<Food> a1 = new ArrayList<Food>();// for customer only

		LocalTime localTime; // Time Reference
		localTime = LocalTime.now(); // for the customer ween ordering

		Food f = new Food();
		a.add(f); // Creating 1 Food

		Food f1 = new Food();
		a.add(f1); // Creating 2 Food

		welcomeMessage(); // Message showing at the Begining of the program, only once to appear!!

		do {

			menu(); // Menu

			menu = sc.nextInt();

			switch (menu) { // SWITCH '1' -> for main menu

			case 1:

				if (Food.foodCount == 0) { // when order has not yet been ordered by a customer

					foodIsZero(); // when Food List is EMPTY 

					for (Food ff : a) // chef input

					{

						System.out.println("Food" + ++fCount + "\n");

						System.out.println("Enter Your Name");
						Cname = sc.next();

						System.out.println("Enter Meal's name");
						Fname = sc.next();

						System.out.println("Enter Salt Amount");
						sa = sc.nextInt();

						System.out.println("Enter Fat Amount");
						fa = sc.nextInt();

						System.out.println("\n");

						ff.cook(Fname, sa, fa, Cname);

						localTime = LocalTime.now();

						hour = localTime.getHour();
						minute = localTime.getMinute();
						second = localTime.getSecond();

					}

					fCount = 0; // for future recyclibility, so the chef can cook his/her own food menu

					System.out
							.println("\nFood Created!!!!\nYummy Yummy. Wait for the Customers!");
					break;

				} else {

					customerOrderToChef(localTime); // Customer Order To Chef appears here if there's an order by a customer

					for (Food ff : a1) {

						customersInfo(sa, fa, tableNo, ff); // customer's info

					}

					System.out.println("\n");

					Food.foodCount = 0; // so the chef may cook food

					break;

				}

			case 2:

				customerMenu(); // Customer's Menu

				menu = sc.nextInt();

				switch (menu) { // SWITCH '2' for customer's menu

				case 1:

					Food f2 = new Food(); // for Customer's ordering
					a1.add(f2);

					System.out.println("Enter Your Name");
					Cname = sc.next();

					System.out.println("Enter Meal's name");
					Fname = sc.next();

					System.out.println("Enter Table's number");
					tableNo = sc.next();

					System.out.println("Enter Salt Amount");
					sa = sc.nextInt();

					System.out.println("Enter Fat Amount");
					fa = sc.nextInt();

					System.out.println("\n");

					f2.cook(Fname, sa, fa, Cname);

					System.out
							.println("Thanks for ordering\nWait a bit and your meal will be there at your table NO: "
									+ tableNo);

					break;

				case 2: // handle checking

					if (Food.foodCount == 0) { // when the chef hasn't cooked food yet

						System.out.println("No Food Yet!");

					}

					else { // when the chef cooks food

						System.out
								.println("\nFood is prepared at the time of '"
										+ hour % 12 % 6
										+ "' o'clock :: Ethiopian Local Time\n");

						for (Food ff : a) {

							chefInfo(fCount, ff); // Chef's Info

						}

						fCount = 0; // for future recyclibility, so the chef can cook his/her own food menu

						checkNote(); // important Note when Checking Food

						do { // a loop to handle checking process

							for (Food ff : a)

							{

								standardCustomMenu(); // checking Menu

								check = sc.nextInt();

								if (check == 1)

								{

									ff.setDefaultTaste(); // setting the values, SALT & FAT, to their OPTIMUM

									System.out
											.println("Wanna Check!\n\n1. Salt\n2. Fat\n3. Both:\n\n");

									check = sc.nextInt();

									if (check == 1) {

										if (ff.getSalt() > ff
												.getOptimumSaltGram()) {

											saltChecking1(ff); // checking Unhealthiness
										}

										else {

											saltChecking2(ff); // checking Healthiness
										}

									}

									else if (check == 2) {

										if (ff.getFat() > ff
												.getOptimumFatGram()) {

											fatChecking1(ff); // checking Unhealthiness
										}

										else {

											fatChecking2(ff); // checking Healthiness
										}
									}

									else if (check == 3) {

										if (ff.getSalt() > ff
												.getOptimumSaltGram()
												&& ff.getFat() > ff
														.getOptimumFatGram()) {

											bothChecking1(ff); // checking Unhealthiness
										}

										else {

											bothChecking2(ff); // checking Healthiness
										}
									}

								}

								else if (check == 2)

								{

									System.out.println("Enter Your Salt rate");
									sa = sc.nextInt();

									System.out.println("Enter Your Fat rate");
									fa = sc.nextInt();

									ff.setCustomTaste(sa, fa); // setting the values, SALT & FAT, to the user's requirment, and upon check

									if (ff.getSalt() > ff.OptimumSaltGram
											&& ff.getFat() > ff.OptimumFatGram) {

										customChecking1(sa, fa, ff); // checking Healthiness

									} else {

										customChecking2(sa, fa, ff); // checking Unhealthiness

									}
								}

							}

							iterate = innerLoopExit(sc); // inner Loop Exit

						} while (iterate == 1);

					}					
										
				}
				
				break; // case's '2' break statement
				
			case 3:

				about(); // About
				
				break;

			default:

				System.out.println("Wrong Input");

				break;

			}
			
			iterate = outerLoopExit(sc); // outer Loop Exit

		} while (iterate != 0);

		/*
		 * FOR DESTRUCTION METHOD ALL @objects are destroyed when the program
		 * terminates !
		 */

		f = null;
		f1 = null;
		// f2 is already destroyed within a function
		a = null;
		a1 = null;

		localTime.now();

		int h = localTime.getHour();
		int m = localTime.getMinute();
		int s = localTime.getSecond();

		System.out.println("DESTROYED SUCCESSFULLY\n\n##Time: " + h % 12 + ":"
				+ m + ":" + s);

		localTime = null;
		h = m = s = 0;

	}

	private static void saltChecking1(Food ff) {
		System.out.println("\tChef's Name: " + ff.getChefName() + "\n");

		System.out.println("\tOptimum of Salt is: " + ff.getOptimumSaltGram());

		System.out.println("\tAmount of Salt in " + ff.getFoodName() + " is "
				+ ff.getSalt());
		System.out.println("\n\tUnhealthy");
	}

	private static void saltChecking2(Food ff) {
		System.out.println("\tChef's Name: " + ff.getChefName() + "\n");

		System.out.println("\tOptimum of Salt is: " + ff.getOptimumSaltGram());
		System.out.println("\tAmount of Salt in " + ff.getFoodName() + " is "
				+ ff.getSalt());
		System.out.println("\n\tHealthy");
	}

	private static void fatChecking1(Food ff) {
		System.out.println("\tChef's Name: " + ff.getChefName() + "\n");

		System.out.println("\tOptimum of Fat is: " + ff.getOptimumFatGram());
		System.out.println("\tAmount of Fat in " + ff.getFoodName() + " is "
				+ ff.getFat());
		System.out.println("\n\tUnhealthy");
	}

	private static void fatChecking2(Food ff) {
		System.out.println("\tChef's Name:" + ff.getChefName() + "\n");

		System.out.println("\tOptimum of Fat is: " + ff.getOptimumFatGram());
		System.out.println("\tAmount of Fat in " + ff.getFoodName() + " is "
				+ ff.getFat());
		System.out.println("\n\tHealthy");
	}

	private static void bothChecking1(Food ff) {
		System.out.println("\tChef's Name: " + ff.getChefName() + "\n");

		System.out.println("\tAmount of Salt in " + ff.getFoodName() + " is "
				+ ff.getSalt());
		System.out.println("\tAmount of Fat in " + ff.getFoodName() + " is "
				+ ff.getFat());

		System.out
				.println("\n\tOptimum of Salt is: " + ff.getOptimumSaltGram());
		System.out.println("\tOptimum of Fat is: " + ff.getOptimumFatGram());

		System.out.println("\n\tUnhealthy");
	}

	private static void bothChecking2(Food ff) {
		System.out.println("\tChef's Name: " + ff.getChefName() + "\n");

		System.out.println("\tAmount of Salt in " + ff.getFoodName() + " is "
				+ ff.getSalt());
		System.out.println("\tAmount of Fat in " + ff.getFoodName() + " is "
				+ ff.getFat());
		System.out
				.println("\n\tOptimum of Salt is: " + ff.getOptimumSaltGram());
		System.out.println("\tOptimum of Fat is: " + ff.getOptimumFatGram());

		System.out.println("\n\tHealthy");
	}

	private static void customChecking1(int sa, int fa, Food ff) {
		System.out.println("\n\n\tChef's Name: " + ff.getChefName());

		System.out.println("\n\tYou Entered:\n");

		System.out.println("\tSalt = " + sa);
		System.out.println("\tFat = " + fa);

		System.out.println("\n\n\tSalt rate in " + ff.getFoodName() + " is: "
				+ ff.getSalt());
		System.out.println("\tFat rate in " + ff.getFoodName() + " is: "
				+ ff.getFat());

		System.out.println("\n\tCASE1");

		System.out.println("\n\tHealthy");
	}

	private static void customChecking2(int sa, int fa, Food ff) {
		System.out.println("\n\n\tChef's Name: " + ff.getChefName());

		System.out.println("\n\tYou Entered:\n");

		System.out.println("\tSalt = " + sa);
		System.out.println("\tFat = " + fa);

		System.out.println("\n\n\tSalt rate in " + ff.getFoodName() + " is: "
				+ ff.getSalt());
		System.out.println("\tFat rate in " + ff.getFoodName() + " is: "
				+ ff.getFat());

		System.out.println("\n\tCASE2");

		System.out.println("\n\tUnHealthy");
	}

	private static void chefInfo(int fCount, Food ff) {
		System.out.println("\nChef's " + ++fCount + " info:-\n\n\t---Name: "
				+ ff.getChefName() + "\n\t---Meal: " + ff.getFoodName()
				+ "\n\t---Food Time of preparation: " + hour % 12 % 6 + ":"
				+ minute + ":" + second + " Ethiopian Local Time"
				+ "\n\t---Was prepared '" + minute + "' minutes" + " and '"
				+ second + "' seconds ago");

		System.out.println("\n");
	}

	private static void customersInfo(int sa, int fa, String tableNo, Food ff) {
		System.out.println("\nPerson's info:-\n\n\t---Name: "
				+ ff.getChefName() + "\n\t---Meal: " + ff.getFoodName()
				+ "\n\t---Table Number: " + tableNo
				+ "\n\t---Amount of Salt in " + ff.getFoodName() + " is " + sa
				+ "\n\t---Amount of Fat in " + ff.getFoodName() + " is " + fa);
	}

	private static void customerOrderToChef(LocalTime localTime) {
		hour = localTime.getHour();
		minute = localTime.getMinute();
		second = localTime.getSecond();

		System.out.println("\n\n######You got an order!! Details:\n\n");

		System.out.println("\nFood was ordered at the time of '" + hour % 12
				% 6 + "' o'clock :: Ethiopian Local Time\n" + "->About "
				+ minute + "' minutes" + " and '" + second
				+ "' seconds ago\n\n");
	}
	
	private static void foodIsZero() {
		System.out.println("\nYou Got 'NO' orders ,,, so.....");
		System.out
				.println("\n###Let us cook a yummy meal now ###\n");
		System.out
				.println("\nThe Ingredients will only make you able to cook 2 meals!!\n\n");
	}

	private static void welcomeMessage() {
		System.out
				.println("\n\n\t\t\tWELOCME TO CHECHEHO RESTURANT!!\n\n\t\t\t**Where You Will Find The Best Food From The Best Chefs With a Delightful, Delicious Pre-main Menu**\n\n\t\t\t->ENJOY!\n\n\t\t\t->Have Fun!\n\n\t\t\t->Pay Reasonably!!!\n\n");
	}

	private static void menu() {
		System.out
				.print("\n\t\t\t1.Chef\n\t\t\t2.Customer\n\t\t\t3.About\n\n\t\t\tSelect:- #");
	}

	private static void customerMenu() {
		System.out
				.println("\nWanna:\n\n\t1.order \t______________\t 2.check the food available?\n\n\t\tSelect: #");
	}

	private static void standardCustomMenu() {
		System.out
				.println("\n\nTo check the food---\n\n1. For Standard Entry!\n2. For Customize Entry\n\n");
	}

	private static void checkNote() {
		System.out
				.println("The checking goes this way:\n\n->One Food at a time");
		System.out
				.println("->Means that if you checked a food once, you will check the next one if you checked again!\n\n");
	}
	
	private static void about() {
		System.out
				.println("\n\n## What the program does is that it allows a CUSTOMER and a CHEF to communicate easily.\n\n## A CHEF can COOK food and CHECK for available ORDERS.\n\n## Also, a CUSTOMER can ORDER food and/or CHECK available food for HEALTH convenience.\n\n## For code checking, check the -#Github Resiprotery- and -#Google Drive Link-.\n\n## For the links and/or any concerns about the code and/or the program, please contact:\n\n-> #Email:- nabil.alanssi19@gmail.com\n");
	}

	private static int innerLoopExit(Scanner sc) {
		int iterate;
		System.out.println("\n\nPress any key to go back or zero to exit");
		iterate = sc.nextInt();
		System.out.println("\n");
		return iterate;
	}

	private static int outerLoopExit(Scanner sc) {
		int iterate;
		System.out
				.println("\n\nPress any key to go back or zero to exit and DESTROY the program");
		iterate = sc.nextInt();
		System.out.println("\n");
		return iterate;
	}

}
