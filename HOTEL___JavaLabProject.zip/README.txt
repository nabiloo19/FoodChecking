
############################################################################################
										      ######
This is a Java Lab Project for Second Year Computer Science Students, Second Semester.######
										      ######
What the program does is that it allows a CUSTOMER and a CHEF to communicate easily.  ######
										      ######
For code checking, check the 'Github Resiprotery' and 'Google Drive Link'             ######
										      ######
-> Github Link: 								      ######
-> GDrive Link: 								      ######
										      ######
For any concerns about the code and/or the program, please contact:                   ######
										      ######
-> Email:- nabil.alanssi19@gmail.com				                      ######
										      ######
############################################################################################
										     